module.exports = require('eslint-plugin-jane/prettier')
